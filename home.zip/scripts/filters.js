'use strict';

/* Filters */

var homeFilters = angular.module('homeFilters', []);
